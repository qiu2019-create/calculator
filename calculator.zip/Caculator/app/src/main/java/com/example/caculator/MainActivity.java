package com.example.caculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.math.BigDecimal;
import java.util.Stack;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button b_0,b_1,b_2,b_3,b_4,b_5,b_6,
            b_7,b_8,b_9,b_C,b_DEL,b_per,b_squ,
            b_sin,b_cos,b_change,b_squ2,
            b_no,b_left,b_right,
            b_div,b_mul,b_sub,b_add,b_point,b_equ;
    EditText t1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b_0 = findViewById(R.id.b_0);
        b_0.setOnClickListener(this);

        b_1 = findViewById(R.id.b_1);
        b_1.setOnClickListener(this);

        b_2 = findViewById(R.id.b_2);
        b_2.setOnClickListener(this);

        b_3 = findViewById(R.id.b_3);
        b_3.setOnClickListener(this);

        b_4 = findViewById(R.id.b_4);
        b_4.setOnClickListener(this);

        b_5 = findViewById(R.id.b_5);
        b_5.setOnClickListener(this);

        b_6 = findViewById(R.id.b_6);
        b_6.setOnClickListener(this);

        b_7 = findViewById(R.id.b_7);
        b_7.setOnClickListener(this);

        b_8 = findViewById(R.id.b_8);
        b_8.setOnClickListener(this);

        b_9 = findViewById(R.id.b_9);
        b_9.setOnClickListener(this);

        b_C = findViewById(R.id.b_C);
        b_C.setOnClickListener(this);

        b_DEL = findViewById(R.id.b_DEL);
        b_DEL.setOnClickListener(this);

        b_per = findViewById(R.id.b_per);
        b_per.setOnClickListener(this);

        b_squ = findViewById(R.id.b_squ);
        b_squ.setOnClickListener(this);

        b_sin = findViewById(R.id.b_sin);
        b_sin.setOnClickListener(this);

        b_cos = findViewById(R.id.b_cos);
        b_cos.setOnClickListener(this);

        b_change = findViewById(R.id.b_change);
        b_change.setOnClickListener(this);

        b_squ2 = findViewById(R.id.b_squ2);
        b_squ2.setOnClickListener(this);

        b_no = findViewById(R.id.b_no);
        b_no.setOnClickListener(this);

        b_left = findViewById(R.id.b_left);
        b_left.setOnClickListener(this);

        b_right = findViewById(R.id.b_right);
        b_right.setOnClickListener(this);

        b_div = findViewById(R.id.b_div);
        b_div.setOnClickListener(this);

        b_mul = findViewById(R.id.b_mul);
        b_mul.setOnClickListener(this);

        b_sub = findViewById(R.id.b_sub);
        b_sub.setOnClickListener(this);

        b_add = findViewById(R.id.b_add);
        b_add.setOnClickListener(this);

        b_point = findViewById(R.id.b_point);
        b_point.setOnClickListener(this);

        b_equ = findViewById(R.id.b_equ);
        b_equ.setOnClickListener(this);

        t1 = findViewById(R.id.t1);
    }

    @Override
    public void onClick(View v) {
        String str = t1.getText().toString();    //文本框内容

        switch(v.getId()){
            case R.id.b_DEL:     //清除1个
                if(str.length()>1){   //长度不为1，截取0到str.length()-2的子串
                    str=str.substring(0,str.length()-1);
                }
                else{   //长度为1直接置0
                    str="0";
                }
                t1.setText(str);
                break;
            case R.id.b_C:    //归零
                str="0";    //置0
                t1.setText(str);
                break;
            case R.id.b_0:
                if (str.equals("0")){     //为0
                    str="0";
                }
                else{    //不为0，在后面加0
                    str+="0";
                }
                t1.setText(str);
                break;
            case R.id.b_1:
                if (str.equals("0")){     //初始值0，直接置1
                    str="1";
                }
                else{     //不为0，后面加1
                    str+="1";
                }
                t1.setText(str);
                break;
            case R.id.b_2:
                if (str.equals("0")){      //初始值0，直接置2
                    str="2";
                }
                else{      //不为0，后面加2
                    str+="2";
                }
                t1.setText(str);
                break;
            case R.id.b_3:
                if (str.equals("0")){      //初始值0，直接置3
                    str="3";
                }
                else{      //不为0，后面加3
                    str+="3";
                }
                t1.setText(str);
                break;
            case R.id.b_4:
                if (str.equals("0")){      //初始值0，直接置4
                    str="4";
                }
                else{     //不为0，后面加4
                    str+="4";
                }
                t1.setText(str);
                break;
            case R.id.b_5:
                if (str.equals("0")){      //初始值0，直接置5
                    str="5";
                }
                else{     //不为0，后面加5
                    str+="5";
                }
                t1.setText(str);
                break;
            case R.id.b_6:
                if (str.equals("0")){      //初始值0，直接置6
                    str="6";
                }
                else{     //不为0，后面加6
                    str+="6";
                }
                t1.setText(str);
                break;
            case R.id.b_7:
                if (str.equals("0")){      //初始值0，直接置7
                    str="7";
                }
                else{     //不为0，后面加7
                    str+="7";
                }
                t1.setText(str);
                break;
            case R.id.b_8:
                if (str.equals("0")){      //初始值0，直接置8
                    str="8";
                }
                else{     //不为0，后面加8
                    str+="8";
                }
                t1.setText(str);
                break;
            case R.id.b_9:
                if (str.equals("0")){      //初始值0，直接置9
                    str="9";
                }
                else{     //不为0，后面加9
                    str+="9";
                }
                t1.setText(str);
                break;
            case R.id.b_point:    //小数点
                //在+-×÷·后不可以加该符号，提示错误
                if(str.charAt(str.length()-1)=='+'||str.charAt(str.length()-1)=='-'||str.charAt(str.length()-1)=='×'||str.charAt(str.length()-1)=='÷'||str.charAt(str.length()-1)=='.'){
                    Toast.makeText(MainActivity.this,"输入错误",Toast.LENGTH_LONG).show();
                    t1.setText(str);
                }
                else{    //在后面加·
                    str+=".";
                    t1.setText(str);
                }
                break;
            case R.id.b_add:     //加法
                //在+-×÷·后不可以加该符号，提示错误
                if(str.charAt(str.length()-1)=='+'||str.charAt(str.length()-1)=='-'||str.charAt(str.length()-1)=='×'||str.charAt(str.length()-1)=='÷'||str.charAt(str.length()-1)=='.'){
                    Toast.makeText(MainActivity.this,"输入错误",Toast.LENGTH_LONG).show();
                    t1.setText(str);
                }
                else{
                    str+="+";
                    t1.setText(str);
                }
                break;
            case R.id.b_sub:    //减法
                //在+-×÷·后不可以加该符号，提示错误
                if(str.charAt(str.length()-1)=='+'||str.charAt(str.length()-1)=='-'||str.charAt(str.length()-1)=='×'||str.charAt(str.length()-1)=='÷'||str.charAt(str.length()-1)=='.'){
                    Toast.makeText(MainActivity.this,"输入错误",Toast.LENGTH_LONG).show();
                    t1.setText(str);
                }
                else {
                    str += "-";
                    t1.setText(str);
                }
                break;
            case R.id.b_mul:    //乘法
                //在+-×÷·后不可以加该符号，提示错误
                if(str.charAt(str.length()-1)=='+'||str.charAt(str.length()-1)=='-'||str.charAt(str.length()-1)=='×'||str.charAt(str.length()-1)=='÷'||str.charAt(str.length()-1)=='.'){
                    Toast.makeText(MainActivity.this,"输入错误",Toast.LENGTH_LONG).show();
                    t1.setText(str);
                }
                else {
                    str += "×";
                    t1.setText(str);
                }
                break;
            case R.id.b_div:    //除法
                //在+-×÷·后不可以加该符号，提示错误
                if(str.charAt(str.length()-1)=='+'||str.charAt(str.length()-1)=='-'||str.charAt(str.length()-1)=='×'||str.charAt(str.length()-1)=='÷'||str.charAt(str.length()-1)=='.'){
                    Toast.makeText(MainActivity.this,"输入错误",Toast.LENGTH_LONG).show();
                    t1.setText(str);
                }
                else {
                    str += "÷";
                    t1.setText(str);
                }
                break;
            case R.id.b_left:  //左括号
                if (str.length()==1){    //长度为1，直接写为(
                    str="(";
                }
                else if(!str.contains("+")&&!str.contains("-")&&!str.contains("×")&&!str.contains("÷")){ //不包含+-×÷的话在前面加(
                    str="("+str;
                }
                else {    //后面加(
                    str += "(";
                }
                t1.setText(str);
                break;
            case R.id.b_right:  //右括号
                if (str.length()==1){     //长度为1，不允许使用右括号
                    str="0";
                }
                else {    //后面加)
                    str += ")";
                }
                t1.setText(str);
                break;
            case R.id.b_equ:    //等于
                //在+-×÷后式子未结束，不可以得出结果，提示错误
                if(str.charAt(str.length()-1)=='+'||str.charAt(str.length()-1)=='-'||str.charAt(str.length()-1)=='×'||str.charAt(str.length()-1)=='÷'){
                    Toast.makeText(MainActivity.this,"式子未结束",Toast.LENGTH_LONG).show();
                    t1.setText(str);
                }
                else {
                    String ero = isMatched(str);    //检查式子是否正确
                    if (ero.equals("no error")) {   //检验式子无误，可以计算结果
                        String re = getResult();
                        if (re.contains("Infinity")) {    //被除数为0，提示错误
                            Toast.makeText(MainActivity.this, "0不能作为被除数", Toast.LENGTH_LONG).show();
                            t1.setText("0");
                        } else {
                            t1.setText(re);    //输出正确结果
                        }
                    } else {
                        Toast.makeText(MainActivity.this, ero, Toast.LENGTH_LONG).show();
                    }
                }
                break;
            case R.id.b_squ:   //开方
                if(str.charAt(0)=='-'){    //被开方数不能为负数
                    Toast.makeText(MainActivity.this,"被开方数不能为负",Toast.LENGTH_LONG).show();
                    t1.setText("0");
                }
                else if(str.contains("+")||str.contains("-")||str.contains("×")||str.contains("÷")){//不能含有+-×÷
                    Toast.makeText(MainActivity.this,"不能含有字符",Toast.LENGTH_LONG).show();
                    t1.setText("0");
                }
                else{
                    double x=Double.parseDouble(str);   //转化为double型
                    x=Math.sqrt(x);       //开方
                    String x2=String.format("%.9f",x);//规避极小误差
                    x2 = x2.replaceAll("0+?$", "");//去掉多余的0
                    x2 = x2.replaceAll("[.]$", "");//如最后一位是.则去掉
                    t1.setText(x2);
                }
                break;
            case R.id.b_per:    //百分号
                double per=Double.parseDouble(str);   //转化为double型
                per=per/100;
                String per2=""+per;
                per2 = per2.replaceAll("0+?$", "");//去掉多余的0
                per2 = per2.replaceAll("[.]$", "");//如最后一位是.则去掉
                t1.setText(per2);
                break;
            case R.id.b_sin:
                double sinn=Double.parseDouble(str);   //转化为double型
                sinn=Math.toRadians(sinn);   //将角度转换为弧度
                sinn=Math.sin(sinn);
                String sinn1=String.format("%.9f",sinn);//规避极小误差
                sinn1 = sinn1.replaceAll("0+?$", "");//去掉多余的0
                sinn1 = sinn1.replaceAll("[.]$", "");//如最后一位是.则去掉
                t1.setText(sinn1);
                break;
            case R.id.b_cos:
                double coss=Double.parseDouble(str);   //转化为double型
                coss=Math.toRadians(coss);   //将角度转换为弧度
                coss=Math.cos(coss);
                String coss1=String.format("%.9f",coss);//规避极小误差
                coss1 = coss1.replaceAll("0+?$", "");//去掉多余的0
                coss1 = coss1.replaceAll("[.]$", "");//如最后一位是.则去掉
                t1.setText(coss1);
                break;
            case R.id.b_change:    //正负数改变
                if(str.charAt(0)>='0'&&str.charAt(0)<='9'){   //第一位是0到9的数字
                    if(str.equals("0")){    //0还是0
                        t1.setText("0");
                    }
                    else{     //正数前面加负号
                        t1.setText("-"+str);
                    }
                }
                else if(str.charAt(0)=='-')    //如果是负数，去掉前面的负号，截取1到str.length()-1的子串
                    t1.setText(str.substring(1,str.length()));
                else
                    t1.setText(str);
                break;
            case R.id.b_no:    //阶乘
                if(str.charAt(0)=='-'){    //不能为负数，提示错误
                    Toast.makeText(MainActivity.this,"操作数不能为负",Toast.LENGTH_LONG).show();
                    t1.setText("0");
                }
                else if(str.contains("+")||str.contains("-")||str.contains("×")||str.contains("÷")||str.contains(".")){//不能含有+-×÷.
                    Toast.makeText(MainActivity.this,"不能含有字符",Toast.LENGTH_LONG).show();
                    t1.setText("0");
                }
                else{   //正整数
                    double n = Double.parseDouble(str);   //转化为double型
                    double temp = 1;
                    for (int i = 2; i <= n; i++){  //阶乘运算
                        temp *= i;
                    }
                    String n2=String.format("%.9f",temp);//规避极小误差
                    n2 = n2.replaceAll("0+?$", "");//去掉多余的0
                    n2 = n2.replaceAll("[.]$", "");//如最后一位是.则去掉
                    t1.setText(n2);
                }
                break;
            case R.id.b_squ2:   //平方
                double a = Double.parseDouble(str);   //转化为double型
                double a1 = a * a;
                String a2=String.format("%.9f",a1);//规避极小误差
                a2 = a2.replaceAll("0+?$", "");//去掉多余的0
                a2 = a2.replaceAll("[.]$", "");//如最后一位是.则去掉
                t1.setText(a2);
                break;
            default:
                break;
        }
    }

    //检查式子的正确性
    public static String isMatched(String infix){
        Stack<String> stack=new Stack<String>();   //String型的栈
        for (int i=0;i<infix.length();i++){     //遍历String infix
            char ch=infix.charAt(i);
            switch(ch){
                case'(':   //式子中如果有左括号，左括号入栈
                    stack.push(ch+"");
                    break;
                case')':    //如果栈为空或者栈顶不是左括号，缺少左括号
                    if(stack.isEmpty()||!stack.pop().equals("("))
                        return "expect   (";
            }
        }
        //如果栈为空则没有错误，返回no error；否则缺少右括号
        return(stack.isEmpty())?"no error":"expect   )";
    }

    //得出运算结果
    public String getResult(){
        String infix = t1.getText().toString();     //式子（中缀表达式）
        StringBuffer postfix=toPostfix(infix);      //后缀表达式（操作符在后）
        Double result=toValue(postfix);            //计算后缀表达式
        String re=String.format("%.7f",result);     //规避极小误差
        re = re.replaceAll("0+?$", "");//去掉多余的0
        re = re.replaceAll("[.]$", "");//如最后一位是.则去掉
        return re;
    }

    //将中缀表达式转换成后缀表达式
    public static StringBuffer toPostfix(String infix){
        Stack<String> stack=new Stack<String>();   //运算符栈,顺序栈
        StringBuffer postfix=new StringBuffer(infix.length()*2);   //后缀表达式字符串
        int i=0;
        while(i<infix.length()){
            char ch=infix.charAt(i);
            switch(ch){
                case '+':
                case '-':
                    while(!stack.isEmpty()&&!stack.peek().equals("(")) //如果栈不为空且栈顶元素不是"(",则出栈
                        postfix.append(stack.pop());   //且添加到后缀表达式串
                    stack.push(ch+"");        //ch入栈
                    i++;
                    break;

                case '×':
                case '÷':
                    while(!stack.isEmpty()&&(stack.peek().equals("×")||stack.peek().equals("÷")))  //如果栈顶元素不为空且栈顶元素是"*"或是"/"时,则出栈
                        postfix.append(stack.pop());
                    stack.push(ch+"");
                    i++;
                    break;

                case '(':
                    stack.push(ch+""); //直接入栈
                    i++;
                    break;

                case ')':
                    String out=stack.pop();
                    while(out!=null&&!out.equals("(")){    //如果栈顶元素不为空且不为"("时
                        postfix.append(out);   //添加到后缀表达式串
                        out=stack.pop();   //把此时位于栈顶的"("弹出
                    }
                    i++;
                    break;

                default:
                    while((i<infix.length()&&ch>='0'&&ch<='9')||(i<infix.length()&&ch=='.')){
                        postfix.append(ch);    //如果是数字直接添加到后缀表达式串（输出队列）
                        i++;
                        if(i<infix.length())
                            ch=infix.charAt(i);
                    }
                    postfix.append(" ");
            }

        }
        while(!stack.isEmpty())       //所有运算符出栈
            postfix.append(stack.pop());   //添加到后缀表达式中
        return postfix;
    }

    //计算后缀表达式
    public static Double toValue(StringBuffer postfix){
        Stack<Double> stack=new Stack<Double>();   //操作数栈,链式栈
        double value=0;     //操作数
        int j=0;
        for(int i=0;i<postfix.length();i++){
            j=i;          //操作数的第1个数字
            char ch=postfix.charAt(i);
            if ((ch>='0'&&ch<='9')||ch=='.') {    //处理操作数
                value=0;
                while(ch!=' '){
                    while(ch!=' '&&ch!='.'){   //没有遇到小数点
                        value=value*10+ch-'0';
                        j++;      //j往后移
                        ch=postfix.charAt(++i);
                    }
                    if(ch!=' '&&ch=='.')    //遇到了小数点
                        ch=postfix.charAt(++i);
                    while(ch!=' '&&(i>=j+1)){  //必须保证要在小数点的后面
                        BigDecimal valueBD=new BigDecimal(Double.toString(value));
                        BigDecimal chBD=new BigDecimal(Double.toString(ch-'0'));
                        BigDecimal nBD=new BigDecimal(Double.toString(Math.pow(10,i-j)));   //10的i-j次方
                        double temp=chBD.divide(nBD).doubleValue();
                        BigDecimal tempBD=new BigDecimal(Double.toString(temp));
                        value=valueBD.add(tempBD).doubleValue();
                        ch=postfix.charAt(++i);
                    }

                    stack.push(value);
                }

            }
            else{      //处理运算符
                if(ch!=' '){
                    Double y=stack.pop();     //先弹出右操作数
                    Double x=stack.pop();     //左操作数
                    switch(ch){
                        case'+':
                            value=x+y;
                            break;
                        case'-':
                            value=x-y;
                            break;
                        case'×':
                            value=x*y;
                            break;
                        case'÷':
                            value=x/y;
                            break;
                    }
                    stack.push(value);   //计算结果入栈
                }
            }

        }
        return stack.pop();    //最终结果
    }
}